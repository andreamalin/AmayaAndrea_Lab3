﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class new_sphere : MonoBehaviour
{
    public GameObject preFab;
    private GameObject sphere;
    public Text score;

    public GameObject pauseMenu;
    private bool isPaused = false;



    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1.0f;
        sphere = Instantiate(preFab, new Vector3(3.83f, 0.35f, 3.89f), Quaternion.identity);
    }

    // Update is called once per frame
    void Update()
    {
        

        if (Input.GetButtonDown("Enter") && !sphere)
        {
            Time.timeScale = 1.0f;
            sphere = Instantiate(preFab, new Vector3(3.83f, 0.35f, 3.89f), Quaternion.identity);
        }

        if (Input.GetButtonDown("Cancel"))
        {
            onPause();
        }
    }

    public void onPause()
    {
        if (pauseMenu)
        {
            pauseMenu.SetActive(!pauseMenu.activeSelf);
            isPaused = !isPaused;
            Time.timeScale = isPaused ? 0.0f : 1.0f;
        }

    }




    public void MainScene(int _sceneIndex)
    {
        SceneManager.LoadScene(_sceneIndex);
    }

    public void RestartScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void UpdateScore(int actual)
    {
        score.text = actual.ToString();
    }


}
