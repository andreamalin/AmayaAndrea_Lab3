﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class sphere_mov : MonoBehaviour
{
    private Rigidbody rb;

    public AudioSource coinsound;

    private static int monedas = 0;

    public float velocidad = 0;
    public float jumpForce = 0;
    public float force = 0;

    private new_sphere player;

    private void Awake()
    {
        player = FindObjectOfType<new_sphere>();
    }




    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1.0f;
        rb = GetComponent<Rigidbody>();
        coinsound = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(new Vector3(Input.GetAxis("Horizontal") * velocidad, 0,
            Input.GetAxis("Vertical") * velocidad) * Time.deltaTime, Space.World);

        

        if (Input.GetButtonDown("Jump"))
        {
            Jump();
        }



    }

    private void FixedUpdate()
    {
        if (rb)
        {
            rb.AddForce(Input.GetAxis("Horizontal") * force, 0, Input.GetAxis("Vertical") * force);
        }
    }

    void Jump()
    {
        if (rb)
        {
            if (Mathf.Abs(rb.velocity.y) < 0.05f)
            {
                rb.AddForce(0, jumpForce, 0, ForceMode.Impulse);
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Coin"))
        {
            sphere_mov.monedas++;
            player.UpdateScore(monedas);
            coinsound.Play();
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.CompareTag("Respawn"))
        {
            if (sphere_mov.monedas < 3)
            {
                Destroy(gameObject);
            }
            else
            {
                Destroy(collision.gameObject);
            }

        }
    }

    public int getScore()
    {
        return sphere_mov.monedas;
    }




}
